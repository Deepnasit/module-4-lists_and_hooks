import React from "react";
import MovableElement from "./MovableElement";
import "./App.css";

function App() {
  return (
    <div>
      <MovableElement />
    </div>
  );
}

export default App;
