import React, { useState } from "react";
import TodoItem from "./TodoItem";

const TodoList = () => {
  const [items, setItems] = useState([
    { id: 1, text: "Eggs" },
    { id: 2, text: "Milk" },
    { id: 3, text: "Cheese" },
  ]);
  const [newItem, setNewItem] = useState("");

  const addItem = () => {
    if (newItem.trim()) {
      setItems([...items, { id: Date.now(), text: newItem }]);
      setNewItem("");
    }
  };

  const deleteItem = (id) => {
    setItems(items.filter((item) => item.id !== id));
  };

  const editItem = (id) => {
    const text = prompt(
      "Edit item:",
      items.find((item) => item.id === id).text
    );
    if (text !== null) {
      setItems(
        items.map((item) => (item.id === id ? { ...item, text } : item))
      );
    }
  };

  const deleteAll = () => {
    setItems([]);
  };

  return (
    <div style={styles.container}>
      <h1>Grocery Shopping</h1>
      {items.map((item) => (
        <TodoItem
          key={item.id}
          item={item}
          onDelete={deleteItem}
          onEdit={editItem}
        />
      ))}
      <div style={styles.addItemContainer}>
        <input
          type="text"
          placeholder="Add something to your list"
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          style={styles.addItemInput}
        />
        <button onClick={addItem} style={styles.addButton}>
          Add
        </button>
      </div>
      <button onClick={deleteAll} style={styles.deleteAllButton}>
        Delete List
      </button>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: "darkblue",
    padding: "20px",
    borderRadius: "10px",
    width: "300px",
    margin: "50px auto",
    color: "white",
    textAlign: "center",
  },
  addItemContainer: {
    display: "flex",
    marginTop: "20px",
  },
  addItemInput: {
    flex: 1,
    padding: "10px",
    borderRadius: "5px",
    border: "none",
    marginRight: "10px",
  },
  addButton: {
    padding: "10px",
    borderRadius: "5px",
    border: "none",
    backgroundColor: "#5a67d8",
    color: "white",
    cursor: "pointer",
  },
  deleteAllButton: {
    marginTop: "20px",
    padding: "10px",
    borderRadius: "5px",
    border: "none",
    backgroundColor: "#e53e3e",
    color: "white",
    cursor: "pointer",
  },
};

export default TodoList;
