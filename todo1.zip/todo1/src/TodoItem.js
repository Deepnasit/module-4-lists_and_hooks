import React from "react";
import { RiDeleteBin5Line } from "react-icons/ri";
import { FaRegEdit } from "react-icons/fa";
import { BiColor } from "react-icons/bi";

const TodoItem = ({ item, onDelete, onEdit }) => {
  return (
    <div style={styles.itemContainer}>
      <input type="text" value={item.text} readOnly style={styles.itemInput} />
      <button onClick={() => onDelete(item.id)} style={styles.deleteButton}>
        <RiDeleteBin5Line />
      </button>
      <button onClick={() => onEdit(item.id)} style={styles.editButton}>
        <FaRegEdit />
      </button>
    </div>
  );
};

const styles = {
  itemContainer: {
    display: "flex",
    alignItems: "center",
    marginBottom: "10px",
  },
  itemInput: {
    flex: 1,
    padding: "10px",
    borderRadius: "5px",
    border: "none",
    background: "linear-gradient(to right, #a1c4fd, #c2e9fb)",
    marginRight: "10px",
  },
  deleteButton: {
    marginRight: "5px",
    cursor: "pointer",
    background: "none",
    border: "none",
  },
  editButton: {
    cursor: "pointer",
    background: "none",
    border: "none",
  },
};

export default TodoItem;
