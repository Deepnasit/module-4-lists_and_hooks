import React from "react";

const PublicViews = () => {
  return (
    <div style={{ padding: "20px", background: "#f8f9fa", flex: 1 }}>
      Public Views
    </div>
  );
};

export default PublicViews;
