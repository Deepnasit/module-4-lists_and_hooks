import React from "react";

const Footer = () => {
  return (
    <footer
      style={{
        padding: "10px",
        background: "#007bff",
        color: "white",
      }}
    >
      Footer
    </footer>
  );
};

export default Footer;
