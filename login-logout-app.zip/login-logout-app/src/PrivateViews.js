import React from "react";

const PrivateViews = () => {
  return (
    <div style={{ padding: "20px", background: "#f8f9fa", flex: 1 }}>
      Private Views
    </div>
  );
};

export default PrivateViews;
