import React from "react";

const Nav = ({ isLoggedIn, handleLoginLogout }) => {
  return (
    <nav
      style={{
        padding: "10px",
        background: "#007bff",
        color: "white",
      }}
    >
      <span>Navigation</span>
      <button
        onClick={handleLoginLogout}
        style={{ float: "right", marginRight: "10px" }}
      >
        {isLoggedIn ? "Logout" : "Login"}
      </button>
    </nav>
  );
};

export default Nav;
