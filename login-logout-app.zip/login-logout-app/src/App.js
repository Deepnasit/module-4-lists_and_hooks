import React, { useState } from "react";
import Nav from "./Nav";
import Footer from "./Footer";
import PublicViews from "./PublicViews";
import PrivateViews from "./PrivateViews";
import "./App.css";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLoginLogout = () => {
    setIsLoggedIn(!isLoggedIn);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh" }}>
      <Nav isLoggedIn={isLoggedIn} handleLoginLogout={handleLoginLogout} />
      {isLoggedIn ? <PrivateViews /> : <PublicViews />}
      <Footer />
    </div>
  );
}

export default App;
