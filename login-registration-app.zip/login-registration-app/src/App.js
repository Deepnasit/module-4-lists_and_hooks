import React, { useState } from "react";
import { Button } from "react-bootstrap";
import LoginModal from "./LoginModal";
import RegisterModal from "./RegisterModal";

function App() {
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);

  const handleCloseLogin = () => setShowLogin(false);
  const handleShowLogin = () => setShowLogin(true);

  const handleCloseRegister = () => setShowRegister(false);
  const handleShowRegister = () => setShowRegister(true);

  return (
    <div className="App">
      <Button variant="primary" onClick={handleShowLogin}>
        Modal Login Form
      </Button>
      <br></br>
      <br></br>
      <Button variant="primary" onClick={handleShowRegister}>
        Modal Registration Form
      </Button>

      <LoginModal
        show={showLogin}
        handleClose={handleCloseLogin}
        handleShowRegister={handleShowRegister}
      />
      <RegisterModal show={showRegister} handleClose={handleCloseRegister} />
    </div>
  );
}

export default App;
