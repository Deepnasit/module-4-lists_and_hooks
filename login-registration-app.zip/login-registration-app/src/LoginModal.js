import React from "react";
import { Modal, Button, Form } from "react-bootstrap";

const LoginModal = ({ show, handleClose, handleShowRegister }) => {
  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Login to My Account</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group controlId="formEmail">
            <Form.Label>Email address</Form.Label>
            <Form.Control type="email" placeholder="Enter email" />
          </Form.Group>
          <Form.Group controlId="formPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" placeholder="Password" />
          </Form.Group>
          <Form.Group controlId="formBasicCheckbox">
            <Form.Check type="checkbox" label="Remember Me On This Computer" />
          </Form.Group>
          <Button variant="primary" type="submit" aria-label="center">
            Login
          </Button>
          <div className="mt-3">
            <a href="#">Forgot Your Password?</a>
            <br></br>
            <br></br>
            <a href="#" onClick={handleShowRegister}>
              Create a New Account
            </a>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default LoginModal;
