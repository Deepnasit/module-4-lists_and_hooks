import React from "react";
import ListView from "./ListView";
import "./App.css";

function App() {
  const items = [
    { id: 1, name: "BANANA" },
    { id: 2, name: "KIWI" },
    { id: 3, name: "MANGO" },
    { id: 4, name: "APPLE" },
  ];
  return (
    <div>
      <h1>List View</h1>
      <ListView items={items} />
    </div>
  );
}

export default App;
